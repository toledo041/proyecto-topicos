﻿Imports System.Data.SqlClient
Imports ProyectoSql.RegisterEmpreneurForm
Imports System.Runtime.InteropServices

Public Class RegisterComplementaryActivityCompanyForm

    Public accion As String = "register"
    Public idComplementaryActivityCompany As Integer = 0


    Private Sub RegisterComplementaryActivityCompanyForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadComboBoxComplementaryActivity()
        loadComboBoxCompany()
    End Sub

    Private Sub RegisterComplementaryActivityCompanyForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim form1 As New ComplementaryActivityCompanyForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub ActionBtn_Click(sender As Object, e As EventArgs) Handles ActionBtn.Click
        Dim idComplementaryActivity As Integer = 0
        Dim idCompany As Integer = 0

        If ComplementaryActivityComboBox.SelectedItem IsNot Nothing Then
            ' Obtener el objeto ComboBoxItem seleccionado
            Dim itemSeleccionado As ComboBoxComplementaryActivityItem = DirectCast(ComplementaryActivityComboBox.SelectedItem, ComboBoxComplementaryActivityItem)

            ' Obtener el ID del elemento seleccionado
            Dim idSeleccionado As Integer = itemSeleccionado.idComplementaryActivity
            idComplementaryActivity = idSeleccionado

        End If

        If CompanyComboBox.SelectedItem IsNot Nothing Then
            ' Obtener el objeto ComboBoxItem seleccionado
            Dim itemSeleccionado As ComboBoxCompanyItem = DirectCast(CompanyComboBox.SelectedItem, ComboBoxCompanyItem)

            ' Obtener el ID del elemento seleccionado
            Dim idSeleccionado As Integer = itemSeleccionado.idCompany
            idCompany = idSeleccionado
        End If

        If idComplementaryActivity = 0 Or idCompany = 0 Then
            MessageBox.Show("You must fill in all fields to continue", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            If accion = "register" Then

                Dim connectionString As String = ModuleGlobal.connectionString
                Dim consulta As String = "INSERT INTO ComplementaryActivityCompany(idComplementaryActivity,idCompany,status,idUserCreate,dateCreate)" &
                    " VALUES (@idComplementaryActivity,@idCompany, 1, @idUser, GETDATE())"

                ' Crear una conexión
                Using conexion As New SqlConnection(connectionString)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar parámetros con valores
                            comando.Parameters.AddWithValue("@idComplementaryActivity", idComplementaryActivity)
                            comando.Parameters.AddWithValue("@idCompany", idCompany)
                            comando.Parameters.AddWithValue("@idUser", ModuleGlobal.idUser)


                            ' Ejecutar la consulta de inserción
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            Dim form1 As New ComplementaryActivityCompanyForm()
                            form1.Show()
                            Me.Hide()
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            Else
                'Update
                'MessageBox.Show("Dentro de update", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Dim connectionString As String = ModuleGlobal.connectionString
                Dim consulta As String = "UPDATE ComplementaryActivityCompany SET idComplementaryActivity = @idComplementaryActivity, idCompany = @idCompany, idUserModified = @idUser, datemodified = GETDATE()" &
                " WHERE idComplementaryActivityCompany = @id "


                ' Crear una conexión
                Using conexion As New SqlConnection(connectionString)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar parámetros con valores
                            comando.Parameters.AddWithValue("@idComplementaryActivity", idComplementaryActivity)
                            comando.Parameters.AddWithValue("@idCompany", idCompany)
                            comando.Parameters.AddWithValue("@idUser", ModuleGlobal.idUser)
                            comando.Parameters.AddWithValue("@id", idComplementaryActivityCompany)


                            ' Ejecutar la consulta de inserción
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            Dim form1 As New ComplementaryActivityCompanyForm()
                            form1.Show()
                            Me.Hide()
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End If

        End If
    End Sub

    Private Sub loadComboBoxComplementaryActivity()
        ' Ajusta la cadena de conexión según tu entorno
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL para obtener datos
        Dim consulta As String = "SELECT idComplementaryActivity ,activityname FROM ComplementaryActivity where status = 1"

        Try
            ' Usar SqlConnection para conectarse a la base de datos
            Using conexion As New SqlConnection(cadenaConexion)
                ' Abrir la conexión
                conexion.Open()

                ' Usar SqlCommand para ejecutar la consulta
                Using comando As New SqlCommand(consulta, conexion)
                    ' Usar SqlDataReader para leer los resultados de la consulta
                    Using reader As SqlDataReader = comando.ExecuteReader()
                        ' Limpiar los elementos existentes en el ComboBox                        
                        ComplementaryActivityComboBox.Items.Clear()

                        ' Iterar a través de los resultados y agregar elementos al ComboBox
                        While reader.Read()
                            ' Agregar un elemento al ComboBox utilizando los datos de la consulta                            
                            ComplementaryActivityComboBox.Items.Add(New ComboBoxComplementaryActivityItem() With {
                                .idComplementaryActivity = reader.GetInt32(0),
                                .activityname = reader.GetString(1)
                            })
                        End While

                        ' Seleccionar el primer elemento si hay al menos uno
                        If ComplementaryActivityComboBox.Items.Count > 0 Then
                            ComplementaryActivityComboBox.SelectedIndex = 0
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar datos: " & ex.Message)
        End Try
    End Sub

    Private Sub loadComboBoxCompany()
        ' Ajusta la cadena de conexión según tu entorno
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL para obtener datos
        Dim consulta As String = "SELECT idCompany ,name FROM Company where status = 1;"

        Try
            ' Usar SqlConnection para conectarse a la base de datos
            Using conexion As New SqlConnection(cadenaConexion)
                ' Abrir la conexión
                conexion.Open()

                ' Usar SqlCommand para ejecutar la consulta
                Using comando As New SqlCommand(consulta, conexion)
                    ' Usar SqlDataReader para leer los resultados de la consulta
                    Using reader As SqlDataReader = comando.ExecuteReader()
                        ' Limpiar los elementos existentes en el ComboBox                        
                        CompanyComboBox.Items.Clear()

                        ' Iterar a través de los resultados y agregar elementos al ComboBox
                        While reader.Read()
                            ' Agregar un elemento al ComboBox utilizando los datos de la consulta                            
                            CompanyComboBox.Items.Add(New ComboBoxCompanyItem() With {
                                .idCompany = reader.GetInt32(0),
                                .name = reader.GetString(1)
                            })
                        End While

                        ' Seleccionar el primer elemento si hay al menos uno
                        If CompanyComboBox.Items.Count > 0 Then
                            CompanyComboBox.SelectedIndex = 0
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar datos: " & ex.Message)
        End Try
    End Sub

    Public Class ComboBoxComplementaryActivityItem
        Public Property idComplementaryActivity As Integer
        Public Property activityname As String

        Public Overrides Function ToString() As String
            Return activityname
        End Function
    End Class

    Public Class ComboBoxCompanyItem
        Public Property idCompany As Integer
        Public Property name As String

        Public Overrides Function ToString() As String
            Return name
        End Function
    End Class

    Public Sub setParameters(idComplementaryActivityCompanyObj As String, idComplementaryActivity As String, IdCompany As String)
        idComplementaryActivityCompany = idComplementaryActivityCompanyObj

        For Each item As ComboBoxComplementaryActivityItem In ComplementaryActivityComboBox.Items
            If item.idComplementaryActivity = Convert.ToInt32(idComplementaryActivity) Then
                ComplementaryActivityComboBox.SelectedItem = item
                Exit For
            End If
        Next

        For Each item As ComboBoxCompanyItem In CompanyComboBox.Items
            If item.idCompany = Convert.ToInt32(IdCompany) Then
                CompanyComboBox.SelectedItem = item
                Exit For
            End If
        Next
        accion = "update"
        ActionBtn.Text = "Update"

    End Sub
End Class