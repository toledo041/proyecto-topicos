﻿Imports System.Data.SqlClient
Imports System.Runtime.InteropServices
Imports ProyectoSql.RegisterEmpreneurForm

Public Class RegisterComplementaryActivityForm

    Public action As String = "register"
    Public idComplementaryActivity As String = "0"

    Private Sub actionBtn_Click(sender As Object, e As EventArgs) Handles actionBtn.Click
        Dim activityName As String = activityNameTxt.Text
        Dim idStudent As Integer = 0
        Dim idActivityType As Integer = 0

        If StudentComboBox.SelectedItem IsNot Nothing Then
            ' Obtener el objeto ComboBoxItem seleccionado
            Dim itemSeleccionado As ComboBoxStudentItem = DirectCast(StudentComboBox.SelectedItem, ComboBoxStudentItem)

            ' Obtener el ID del elemento seleccionado
            Dim idSeleccionado As Integer = itemSeleccionado.idStudent
            idStudent = idSeleccionado

        End If

        If ActivityTypeComboBox.SelectedItem IsNot Nothing Then
            ' Obtener el objeto ComboBoxItem seleccionado
            Dim itemSeleccionado As ComboBoxActivityTypeItem = DirectCast(ActivityTypeComboBox.SelectedItem, ComboBoxActivityTypeItem)

            ' Obtener el ID del elemento seleccionado
            Dim idSeleccionado As Integer = itemSeleccionado.idActivityType
            idActivityType = idSeleccionado
        End If

        If activityName = "" Then
            MessageBox.Show("You must fill in all fields to continue", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            If action = "register" Then

                Dim connectionString As String = ModuleGlobal.connectionString
                Dim consulta As String = "INSERT INTO ComplementaryActivity(activityname,idStudent,idActivityType,status,idusercreate,datecreate)" &
                    " VALUES (@activityname,@idStudent,@idActivityType, 1, @idUser, GETDATE())"


                ' Crear una conexión
                Using conexion As New SqlConnection(connectionString)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar parámetros con valores
                            comando.Parameters.AddWithValue("@activityname", activityName)
                            comando.Parameters.AddWithValue("@idStudent", idStudent)
                            comando.Parameters.AddWithValue("@idActivityType", idActivityType)
                            comando.Parameters.AddWithValue("@idUser", ModuleGlobal.idUser)


                            ' Ejecutar la consulta de inserción
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            Dim form1 As New ComplementaryActivityForm()
                            form1.Show()
                            Me.Hide()
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            Else
                'Update
                Dim connectionString As String = ModuleGlobal.connectionString
                Dim consulta As String = "UPDATE ComplementaryActivity SET activityname = @activityname, idStudent = @idStudent, idActivityType = @idActivityType, idusermodified = @idUser, datemodified = GETDATE() " &
                " WHERE idComplementaryActivity = @id "

                ' Crear una conexión
                Using conexion As New SqlConnection(connectionString)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar parámetros con valores
                            comando.Parameters.AddWithValue("@activityname", activityName)
                            comando.Parameters.AddWithValue("@idStudent", idStudent)
                            comando.Parameters.AddWithValue("@idActivityType", idActivityType)
                            comando.Parameters.AddWithValue("@idUser", ModuleGlobal.idUser)
                            comando.Parameters.AddWithValue("@id", idComplementaryActivity)

                            ' Ejecutar la consulta de inserción
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            Dim form1 As New ComplementaryActivityForm()
                            form1.Show()
                            Me.Hide()
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End If

        End If

    End Sub

    Private Sub RegisterComplementaryActivityForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadComboBoxStudent()
        loadComboBoxActivityType()
    End Sub

    Private Sub RegisterComplementaryActivityForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim form1 As New ComplementaryActivityForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub loadComboBoxStudent()
        ' Ajusta la cadena de conexión según tu entorno
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL para obtener datos
        Dim consulta As String = "select idStudent, CONCAT(name,' ',lastName, ' ',mothersthestName) studentName from Student where status = 1"

        Try
            ' Usar SqlConnection para conectarse a la base de datos
            Using conexion As New SqlConnection(cadenaConexion)
                ' Abrir la conexión
                conexion.Open()

                ' Usar SqlCommand para ejecutar la consulta
                Using comando As New SqlCommand(consulta, conexion)
                    ' Usar SqlDataReader para leer los resultados de la consulta
                    Using reader As SqlDataReader = comando.ExecuteReader()
                        ' Limpiar los elementos existentes en el ComboBox
                        StudentComboBox.Items.Clear()

                        ' Iterar a través de los resultados y agregar elementos al ComboBox
                        While reader.Read()
                            ' Agregar un elemento al ComboBox utilizando los datos de la consulta                            
                            StudentComboBox.Items.Add(New ComboBoxStudentItem() With {
                                .idStudent = reader.GetInt32(0),
                                .studentName = reader.GetString(1)
                            })
                        End While

                        ' Seleccionar el primer elemento si hay al menos uno
                        If StudentComboBox.Items.Count > 0 Then
                            StudentComboBox.SelectedIndex = 0
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar datos: " & ex.Message)
        End Try
    End Sub

    Private Sub loadComboBoxActivityType()
        ' Ajusta la cadena de conexión según tu entorno
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL para obtener datos
        Dim consulta As String = "exec dbo.sp_getActivityType"

        Try
            ' Usar SqlConnection para conectarse a la base de datos
            Using conexion As New SqlConnection(cadenaConexion)
                ' Abrir la conexión
                conexion.Open()

                ' Usar SqlCommand para ejecutar la consulta
                Using comando As New SqlCommand(consulta, conexion)
                    ' Usar SqlDataReader para leer los resultados de la consulta
                    Using reader As SqlDataReader = comando.ExecuteReader()
                        ' Limpiar los elementos existentes en el ComboBox                        
                        ActivityTypeComboBox.Items.Clear()

                        ' Iterar a través de los resultados y agregar elementos al ComboBox
                        While reader.Read()
                            ' Agregar un elemento al ComboBox utilizando los datos de la consulta                            
                            ActivityTypeComboBox.Items.Add(New ComboBoxActivityTypeItem() With {
                                .idActivityType = reader.GetInt32(0),
                                .activityname = reader.GetString(1)
                            })
                        End While

                        ' Seleccionar el primer elemento si hay al menos uno
                        If ActivityTypeComboBox.Items.Count > 0 Then
                            ActivityTypeComboBox.SelectedIndex = 0
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar datos: " & ex.Message)
        End Try
    End Sub

    Public Class ComboBoxActivityTypeItem
        Public Property idActivityType As Integer
        Public Property activityname As String

        Public Overrides Function ToString() As String
            Return activityname
        End Function
    End Class

    Public Class ComboBoxStudentItem
        Public Property idStudent As Integer
        Public Property studentName As String

        Public Overrides Function ToString() As String
            Return studentName
        End Function
    End Class

    Public Sub setParameters(idElement As String, activityName As String, idActivity As String, idStudent As String)
        idComplementaryActivity = idElement
        activityNameTxt.Text = activityName

        For Each item As ComboBoxActivityTypeItem In ActivityTypeComboBox.Items
            If item.idActivityType = Convert.ToInt32(idActivity) Then
                ActivityTypeComboBox.SelectedItem = item
                Exit For
            End If
        Next

        For Each item As ComboBoxStudentItem In StudentComboBox.Items
            If item.idStudent = Convert.ToInt32(idStudent) Then
                StudentComboBox.SelectedItem = item
                Exit For
            End If
        Next

        actionBtn.Text = "Update"

    End Sub

End Class