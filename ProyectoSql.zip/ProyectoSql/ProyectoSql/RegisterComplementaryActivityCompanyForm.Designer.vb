﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegisterComplementaryActivityCompanyForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        ComplementaryActivityComboBox = New ComboBox()
        CompanyComboBox = New ComboBox()
        Label2 = New Label()
        ActionBtn = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(8, 10)
        Label1.Name = "Label1"
        Label1.Size = New Size(134, 15)
        Label1.TabIndex = 0
        Label1.Text = "Complementary activity"
        ' 
        ' ComplementaryActivityComboBox
        ' 
        ComplementaryActivityComboBox.FormattingEnabled = True
        ComplementaryActivityComboBox.Location = New Point(8, 28)
        ComplementaryActivityComboBox.Name = "ComplementaryActivityComboBox"
        ComplementaryActivityComboBox.Size = New Size(300, 23)
        ComplementaryActivityComboBox.TabIndex = 1
        ' 
        ' CompanyComboBox
        ' 
        CompanyComboBox.FormattingEnabled = True
        CompanyComboBox.Location = New Point(8, 82)
        CompanyComboBox.Name = "CompanyComboBox"
        CompanyComboBox.Size = New Size(300, 23)
        CompanyComboBox.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(8, 64)
        Label2.Name = "Label2"
        Label2.Size = New Size(59, 15)
        Label2.TabIndex = 2
        Label2.Text = "Company"
        ' 
        ' ActionBtn
        ' 
        ActionBtn.Location = New Point(100, 125)
        ActionBtn.Name = "ActionBtn"
        ActionBtn.Size = New Size(97, 23)
        ActionBtn.TabIndex = 4
        ActionBtn.Text = "Register"
        ActionBtn.UseVisualStyleBackColor = True
        ' 
        ' RegisterComplementaryActivityCompanyForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(318, 157)
        Controls.Add(ActionBtn)
        Controls.Add(CompanyComboBox)
        Controls.Add(Label2)
        Controls.Add(ComplementaryActivityComboBox)
        Controls.Add(Label1)
        Name = "RegisterComplementaryActivityCompanyForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "RegisterComplementaryActivityCompanyForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents ComplementaryActivityComboBox As ComboBox
    Friend WithEvents CompanyComboBox As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ActionBtn As Button
End Class
