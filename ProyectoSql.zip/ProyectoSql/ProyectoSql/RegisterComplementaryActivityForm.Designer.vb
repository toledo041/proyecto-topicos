﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegisterComplementaryActivityForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        activityNameTxt = New TextBox()
        Label2 = New Label()
        StudentComboBox = New ComboBox()
        ActivityTypeComboBox = New ComboBox()
        Label3 = New Label()
        actionBtn = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(8, 10)
        Label1.Name = "Label1"
        Label1.Size = New Size(80, 15)
        Label1.TabIndex = 0
        Label1.Text = "Activity name"
        ' 
        ' activityNameTxt
        ' 
        activityNameTxt.Location = New Point(8, 28)
        activityNameTxt.Name = "activityNameTxt"
        activityNameTxt.Size = New Size(258, 23)
        activityNameTxt.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(8, 63)
        Label2.Name = "Label2"
        Label2.RightToLeft = RightToLeft.Yes
        Label2.Size = New Size(48, 15)
        Label2.TabIndex = 2
        Label2.Text = "Student"
        ' 
        ' StudentComboBox
        ' 
        StudentComboBox.FormattingEnabled = True
        StudentComboBox.Location = New Point(8, 81)
        StudentComboBox.Name = "StudentComboBox"
        StudentComboBox.Size = New Size(258, 23)
        StudentComboBox.TabIndex = 3
        ' 
        ' ActivityTypeComboBox
        ' 
        ActivityTypeComboBox.FormattingEnabled = True
        ActivityTypeComboBox.Location = New Point(8, 137)
        ActivityTypeComboBox.Name = "ActivityTypeComboBox"
        ActivityTypeComboBox.Size = New Size(258, 23)
        ActivityTypeComboBox.TabIndex = 5
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(8, 119)
        Label3.Name = "Label3"
        Label3.Size = New Size(73, 15)
        Label3.TabIndex = 4
        Label3.Text = "Activity type"
        ' 
        ' actionBtn
        ' 
        actionBtn.Location = New Point(84, 177)
        actionBtn.Name = "actionBtn"
        actionBtn.Size = New Size(98, 23)
        actionBtn.TabIndex = 6
        actionBtn.Text = "Register"
        actionBtn.UseVisualStyleBackColor = True
        ' 
        ' RegisterComplementaryActivityForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(278, 214)
        Controls.Add(actionBtn)
        Controls.Add(ActivityTypeComboBox)
        Controls.Add(Label3)
        Controls.Add(StudentComboBox)
        Controls.Add(Label2)
        Controls.Add(activityNameTxt)
        Controls.Add(Label1)
        Name = "RegisterComplementaryActivityForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "RegisterComplementaryActivityForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents activityNameTxt As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents StudentComboBox As ComboBox
    Friend WithEvents ActivityTypeComboBox As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents actionBtn As Button
End Class
