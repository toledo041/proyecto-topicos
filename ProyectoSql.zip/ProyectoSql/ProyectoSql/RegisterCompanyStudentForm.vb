﻿Imports System.Data.SqlClient
Imports System.Diagnostics.Eventing

Public Class RegisterCompanyStudentForm
    Public idCompanyStudentObj As Integer = 0
    Public dateObj As String
    Public workplaceObj As String
    Public idStudentObj As String
    Public nameStudentObj As String

    Public action As String = "register"

    Private Sub RegisterCompanyStudentForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim form1 As New CompanyStudentForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub loadComboBoxStudent()
        ' Ajusta la cadena de conexión según tu entorno
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL para obtener datos
        Dim consulta As String = "select idStudent, CONCAT(name,' ',lastName, ' ',mothersthestName) studentName from Student"

        Try
            ' Usar SqlConnection para conectarse a la base de datos
            Using conexion As New SqlConnection(cadenaConexion)
                ' Abrir la conexión
                conexion.Open()

                ' Usar SqlCommand para ejecutar la consulta
                Using comando As New SqlCommand(consulta, conexion)
                    ' Usar SqlDataReader para leer los resultados de la consulta
                    Using reader As SqlDataReader = comando.ExecuteReader()
                        ' Limpiar los elementos existentes en el ComboBox
                        ComboBox1.Items.Clear()

                        ' Iterar a través de los resultados y agregar elementos al ComboBox
                        While reader.Read()
                            ' Agregar un elemento al ComboBox utilizando los datos de la consulta                            
                            ComboBox1.Items.Add(New ComboBoxStudentItem() With {
                                .idStudent = reader.GetInt32(0),
                                .studentName = reader.GetString(1)
                            })
                        End While

                        ' Seleccionar el primer elemento si hay al menos uno
                        If ComboBox1.Items.Count > 0 Then
                            ComboBox1.SelectedIndex = 0
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar datos: " & ex.Message)
        End Try
    End Sub

    Public Class ComboBoxStudentItem
        Public Property idStudent As Integer
        Public Property studentName As String

        Public Overrides Function ToString() As String
            Return studentName
        End Function
    End Class

    Private Sub RegisterCompanyStudentForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadComboBoxStudent()

    End Sub

    Private Sub actionBtn_Click(sender As Object, e As EventArgs) Handles actionBtn.Click


        Dim idStudent As Integer = 0
        ' Verificar si hay elementos en el ComboBox
        If ComboBox1.SelectedItem IsNot Nothing Then
            ' Obtener el objeto ComboBoxItem seleccionado
            Dim itemSeleccionado As ComboBoxStudentItem = DirectCast(ComboBox1.SelectedItem, ComboBoxStudentItem)

            ' Obtener el ID del elemento seleccionado
            Dim idSeleccionado As Integer = itemSeleccionado.idStudent
            idStudent = idSeleccionado
            ' Puedes utilizar idSeleccionado según tus necesidades
            'MessageBox.Show($"ID seleccionado: {idSeleccionado}")
        End If


        If DatePicker.Text = "" Or workplaceTxt.Text = "" Or ComboBox1.Text = "" Then
            Dim resultado As DialogResult = MessageBox.Show("You must fill in all fields to continue", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            If action = "register" Then
                Dim connectionString As String = ModuleGlobal.connectionString
                Dim consulta As String = "INSERT INTO CompanyStudent(date, workplace, idStudent, status, idUserCreate, dateCreate) VALUES (@date, @workplace, @idStudent, 1, @idUserCreate, GETDATE())"


                ' Crear una conexión
                Using conexion As New SqlConnection(connectionString)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar parámetros con valores
                            comando.Parameters.AddWithValue("@date", DatePicker.Value)
                            comando.Parameters.AddWithValue("@workplace", workplaceTxt.Text)
                            comando.Parameters.AddWithValue("@idStudent", idStudent)
                            comando.Parameters.AddWithValue("@idUserCreate", ModuleGlobal.idUser)


                            ' Ejecutar la consulta de inserción
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            Dim form1 As New CompanyStudentForm()
                            form1.Show()
                            Me.Hide()
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            Else
                'Update

                Dim connectionString As String = ModuleGlobal.connectionString
                Dim consulta As String = "UPDATE CompanyStudent SET date = @date, workplace = @workplace, idStudent = @idStudent, idUserModified = @idUserModified, dateModified = GETDATE() where IdCompanyStudent = @id"


                ' Crear una conexión
                Using conexion As New SqlConnection(connectionString)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar parámetros con valores
                            comando.Parameters.AddWithValue("@date", DatePicker.Value)
                            comando.Parameters.AddWithValue("@workplace", workplaceTxt.Text)
                            comando.Parameters.AddWithValue("@idStudent", idStudent)
                            comando.Parameters.AddWithValue("@idUserModified", ModuleGlobal.idUser)


                            comando.Parameters.AddWithValue("@id", idCompanyStudentObj)


                            ' Ejecutar la consulta de inserción
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            Dim form1 As New CompanyStudentForm()
                            form1.Show()
                            Me.Hide()
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End If
        End If


    End Sub

    Public Sub RecibirParametros(dateStr As String, workplace As String, idStudent As String, nameStudentObj As String, IdCompanyStudent As Integer)
        idCompanyStudentObj = IdCompanyStudent
        DatePicker.Text = dateStr
        workplaceTxt.Text = workplace

        ' Iterar a través de los elementos del ComboBox y seleccionar el que coincida
        For Each item As ComboBoxStudentItem In ComboBox1.Items
            If item.idStudent = Convert.ToInt32(idStudent) Then
                ComboBox1.SelectedItem = item
                Exit For
            End If
        Next

        'MessageBox.Show("dato estudiante " & idStudent & " nombre: "&nameStudentObj, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        actionBtn.Text = "Update"

    End Sub
End Class