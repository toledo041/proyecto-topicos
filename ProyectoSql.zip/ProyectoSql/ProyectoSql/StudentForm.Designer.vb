﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        DataGridView1 = New DataGridView()
        RegisterStudentBtn = New Button()
        CompanyBtn = New Button()
        companyStudentBtn = New Button()
        empreneurBtn = New Button()
        complementaryActivityBtn = New Button()
        Button1 = New Button()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.AllowUserToDeleteRows = False
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 41)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.ReadOnly = True
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(1203, 232)
        DataGridView1.TabIndex = 0
        ' 
        ' RegisterStudentBtn
        ' 
        RegisterStudentBtn.Location = New Point(4, 12)
        RegisterStudentBtn.Name = "RegisterStudentBtn"
        RegisterStudentBtn.Size = New Size(138, 23)
        RegisterStudentBtn.TabIndex = 1
        RegisterStudentBtn.Text = "New student"
        RegisterStudentBtn.UseVisualStyleBackColor = True
        ' 
        ' CompanyBtn
        ' 
        CompanyBtn.Location = New Point(11, 300)
        CompanyBtn.Name = "CompanyBtn"
        CompanyBtn.Size = New Size(115, 23)
        CompanyBtn.TabIndex = 2
        CompanyBtn.Text = "Company"
        CompanyBtn.UseVisualStyleBackColor = True
        ' 
        ' companyStudentBtn
        ' 
        companyStudentBtn.Location = New Point(132, 300)
        companyStudentBtn.Name = "companyStudentBtn"
        companyStudentBtn.Size = New Size(128, 23)
        companyStudentBtn.TabIndex = 3
        companyStudentBtn.Text = "Company student"
        companyStudentBtn.UseVisualStyleBackColor = True
        ' 
        ' empreneurBtn
        ' 
        empreneurBtn.Location = New Point(266, 300)
        empreneurBtn.Name = "empreneurBtn"
        empreneurBtn.Size = New Size(119, 23)
        empreneurBtn.TabIndex = 4
        empreneurBtn.Text = "Empreneur"
        empreneurBtn.UseVisualStyleBackColor = True
        ' 
        ' complementaryActivityBtn
        ' 
        complementaryActivityBtn.Location = New Point(391, 300)
        complementaryActivityBtn.Name = "complementaryActivityBtn"
        complementaryActivityBtn.Size = New Size(157, 23)
        complementaryActivityBtn.TabIndex = 5
        complementaryActivityBtn.Text = "Complementary activity"
        complementaryActivityBtn.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(554, 300)
        Button1.Name = "Button1"
        Button1.Size = New Size(217, 23)
        Button1.TabIndex = 6
        Button1.Text = "Complementary activity company"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' StudentForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1216, 450)
        Controls.Add(Button1)
        Controls.Add(complementaryActivityBtn)
        Controls.Add(empreneurBtn)
        Controls.Add(companyStudentBtn)
        Controls.Add(CompanyBtn)
        Controls.Add(RegisterStudentBtn)
        Controls.Add(DataGridView1)
        Name = "StudentForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Students"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents RegisterStudentBtn As Button
    Friend WithEvents CompanyBtn As Button
    Friend WithEvents companyStudentBtn As Button
    Friend WithEvents empreneurBtn As Button
    Friend WithEvents complementaryActivityBtn As Button
    Friend WithEvents Button1 As Button
End Class
