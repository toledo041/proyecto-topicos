﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegisterEmpreneurForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        requestTxt = New TextBox()
        objetiveTxt = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        codeTxt = New TextBox()
        workteamTxt = New TextBox()
        Label4 = New Label()
        Label5 = New Label()
        StartDatePicker = New DateTimePicker()
        EndDatePicker = New DateTimePicker()
        Label6 = New Label()
        durationTxt = New TextBox()
        Label7 = New Label()
        Label8 = New Label()
        EmployeeComboBox = New ComboBox()
        StudentComboBox = New ComboBox()
        Label9 = New Label()
        ActionBtn = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(49, 15)
        Label1.TabIndex = 0
        Label1.Text = "Request"
        ' 
        ' requestTxt
        ' 
        requestTxt.Location = New Point(12, 27)
        requestTxt.MaxLength = 50
        requestTxt.Name = "requestTxt"
        requestTxt.Size = New Size(249, 23)
        requestTxt.TabIndex = 1
        ' 
        ' objetiveTxt
        ' 
        objetiveTxt.Location = New Point(280, 27)
        objetiveTxt.MaxLength = 50
        objetiveTxt.Name = "objetiveTxt"
        objetiveTxt.Size = New Size(249, 23)
        objetiveTxt.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(280, 9)
        Label2.Name = "Label2"
        Label2.Size = New Size(51, 15)
        Label2.TabIndex = 2
        Label2.Text = "Objetive"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(12, 62)
        Label3.Name = "Label3"
        Label3.Size = New Size(35, 15)
        Label3.TabIndex = 4
        Label3.Text = "Code"
        ' 
        ' codeTxt
        ' 
        codeTxt.Location = New Point(12, 80)
        codeTxt.MaxLength = 50
        codeTxt.Name = "codeTxt"
        codeTxt.Size = New Size(249, 23)
        codeTxt.TabIndex = 5
        ' 
        ' workteamTxt
        ' 
        workteamTxt.Location = New Point(280, 80)
        workteamTxt.MaxLength = 50
        workteamTxt.Name = "workteamTxt"
        workteamTxt.Size = New Size(249, 23)
        workteamTxt.TabIndex = 7
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(280, 62)
        Label4.Name = "Label4"
        Label4.Size = New Size(62, 15)
        Label4.TabIndex = 6
        Label4.Text = "Workteam"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(12, 117)
        Label5.Name = "Label5"
        Label5.Size = New Size(57, 15)
        Label5.TabIndex = 8
        Label5.Text = "Start date"
        ' 
        ' StartDatePicker
        ' 
        StartDatePicker.Format = DateTimePickerFormat.Short
        StartDatePicker.Location = New Point(12, 135)
        StartDatePicker.Name = "StartDatePicker"
        StartDatePicker.Size = New Size(200, 23)
        StartDatePicker.TabIndex = 9
        ' 
        ' EndDatePicker
        ' 
        EndDatePicker.Format = DateTimePickerFormat.Short
        EndDatePicker.Location = New Point(280, 135)
        EndDatePicker.Name = "EndDatePicker"
        EndDatePicker.Size = New Size(200, 23)
        EndDatePicker.TabIndex = 11
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(280, 117)
        Label6.Name = "Label6"
        Label6.Size = New Size(58, 15)
        Label6.TabIndex = 10
        Label6.Text = "Final date"
        ' 
        ' durationTxt
        ' 
        durationTxt.Location = New Point(12, 191)
        durationTxt.MaxLength = 50
        durationTxt.Name = "durationTxt"
        durationTxt.Size = New Size(249, 23)
        durationTxt.TabIndex = 13
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(12, 173)
        Label7.Name = "Label7"
        Label7.Size = New Size(53, 15)
        Label7.TabIndex = 12
        Label7.Text = "Duration"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(280, 173)
        Label8.Name = "Label8"
        Label8.Size = New Size(59, 15)
        Label8.TabIndex = 14
        Label8.Text = "Employee"
        ' 
        ' EmployeeComboBox
        ' 
        EmployeeComboBox.FormattingEnabled = True
        EmployeeComboBox.Location = New Point(280, 191)
        EmployeeComboBox.Name = "EmployeeComboBox"
        EmployeeComboBox.Size = New Size(249, 23)
        EmployeeComboBox.TabIndex = 15
        ' 
        ' StudentComboBox
        ' 
        StudentComboBox.FormattingEnabled = True
        StudentComboBox.Location = New Point(12, 248)
        StudentComboBox.Name = "StudentComboBox"
        StudentComboBox.Size = New Size(249, 23)
        StudentComboBox.TabIndex = 17
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(12, 230)
        Label9.Name = "Label9"
        Label9.Size = New Size(48, 15)
        Label9.TabIndex = 16
        Label9.Text = "Student"
        ' 
        ' ActionBtn
        ' 
        ActionBtn.Location = New Point(218, 294)
        ActionBtn.Name = "ActionBtn"
        ActionBtn.Size = New Size(75, 23)
        ActionBtn.TabIndex = 18
        ActionBtn.Text = "Register"
        ActionBtn.UseVisualStyleBackColor = True
        ' 
        ' RegisterEmpreneurForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(538, 329)
        Controls.Add(ActionBtn)
        Controls.Add(StudentComboBox)
        Controls.Add(Label9)
        Controls.Add(EmployeeComboBox)
        Controls.Add(Label8)
        Controls.Add(durationTxt)
        Controls.Add(Label7)
        Controls.Add(EndDatePicker)
        Controls.Add(Label6)
        Controls.Add(StartDatePicker)
        Controls.Add(Label5)
        Controls.Add(workteamTxt)
        Controls.Add(Label4)
        Controls.Add(codeTxt)
        Controls.Add(Label3)
        Controls.Add(objetiveTxt)
        Controls.Add(Label2)
        Controls.Add(requestTxt)
        Controls.Add(Label1)
        Name = "RegisterEmpreneurForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "RegisterEmpreneurForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents requestTxt As TextBox
    Friend WithEvents objetiveTxt As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents codeTxt As TextBox
    Friend WithEvents workteamTxt As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents StartDatePicker As DateTimePicker
    Friend WithEvents EndDatePicker As DateTimePicker
    Friend WithEvents Label6 As Label
    Friend WithEvents durationTxt As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents EmployeeComboBox As ComboBox
    Friend WithEvents StudentComboBox As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents ActionBtn As Button
End Class
