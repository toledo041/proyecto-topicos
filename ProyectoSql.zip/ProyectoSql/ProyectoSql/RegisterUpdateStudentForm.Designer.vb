﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegisterUpdateStudentForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        nameTxt = New TextBox()
        lastNameTxt = New TextBox()
        Label2 = New Label()
        mothersTxt = New TextBox()
        Label3 = New Label()
        enrollmentTxt = New TextBox()
        enrollmentLbl = New Label()
        curpTxt = New TextBox()
        Label5 = New Label()
        phoneTxt = New TextBox()
        Label6 = New Label()
        rfcTxt = New TextBox()
        Label7 = New Label()
        socialSegurityTxt = New TextBox()
        Label8 = New Label()
        accionBtn = New Button()
        DateTimePicker1 = New DateTimePicker()
        Label4 = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(16, 13)
        Label1.Name = "Label1"
        Label1.Size = New Size(39, 15)
        Label1.TabIndex = 0
        Label1.Text = "Name"
        ' 
        ' nameTxt
        ' 
        nameTxt.Location = New Point(14, 30)
        nameTxt.MaxLength = 50
        nameTxt.Name = "nameTxt"
        nameTxt.Size = New Size(246, 23)
        nameTxt.TabIndex = 1
        ' 
        ' lastNameTxt
        ' 
        lastNameTxt.Location = New Point(279, 30)
        lastNameTxt.MaxLength = 50
        lastNameTxt.Name = "lastNameTxt"
        lastNameTxt.Size = New Size(246, 23)
        lastNameTxt.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(281, 13)
        Label2.Name = "Label2"
        Label2.Size = New Size(61, 15)
        Label2.TabIndex = 2
        Label2.Text = "Last name"
        ' 
        ' mothersTxt
        ' 
        mothersTxt.Location = New Point(12, 82)
        mothersTxt.MaxLength = 50
        mothersTxt.Name = "mothersTxt"
        mothersTxt.Size = New Size(246, 23)
        mothersTxt.TabIndex = 5
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(14, 65)
        Label3.Name = "Label3"
        Label3.Size = New Size(108, 15)
        Label3.TabIndex = 4
        Label3.Text = "Mother's last name"
        ' 
        ' enrollmentTxt
        ' 
        enrollmentTxt.Location = New Point(14, 140)
        enrollmentTxt.MaxLength = 50
        enrollmentTxt.Name = "enrollmentTxt"
        enrollmentTxt.Size = New Size(246, 23)
        enrollmentTxt.TabIndex = 7
        ' 
        ' enrollmentLbl
        ' 
        enrollmentLbl.AutoSize = True
        enrollmentLbl.Location = New Point(16, 123)
        enrollmentLbl.Name = "enrollmentLbl"
        enrollmentLbl.Size = New Size(65, 15)
        enrollmentLbl.TabIndex = 6
        enrollmentLbl.Text = "Enrollment"
        ' 
        ' curpTxt
        ' 
        curpTxt.Location = New Point(279, 140)
        curpTxt.MaxLength = 18
        curpTxt.Name = "curpTxt"
        curpTxt.Size = New Size(246, 23)
        curpTxt.TabIndex = 9
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(281, 123)
        Label5.Name = "Label5"
        Label5.Size = New Size(37, 15)
        Label5.TabIndex = 8
        Label5.Text = "CURP"
        ' 
        ' phoneTxt
        ' 
        phoneTxt.Location = New Point(12, 194)
        phoneTxt.MaxLength = 10
        phoneTxt.Name = "phoneTxt"
        phoneTxt.Size = New Size(246, 23)
        phoneTxt.TabIndex = 11
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(14, 177)
        Label6.Name = "Label6"
        Label6.Size = New Size(41, 15)
        Label6.TabIndex = 10
        Label6.Text = "Phone"
        ' 
        ' rfcTxt
        ' 
        rfcTxt.Location = New Point(281, 194)
        rfcTxt.MaxLength = 13
        rfcTxt.Name = "rfcTxt"
        rfcTxt.Size = New Size(246, 23)
        rfcTxt.TabIndex = 13
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(283, 177)
        Label7.Name = "Label7"
        Label7.Size = New Size(28, 15)
        Label7.TabIndex = 12
        Label7.Text = "RFC"
        ' 
        ' socialSegurityTxt
        ' 
        socialSegurityTxt.Location = New Point(12, 244)
        socialSegurityTxt.MaxLength = 11
        socialSegurityTxt.Name = "socialSegurityTxt"
        socialSegurityTxt.Size = New Size(246, 23)
        socialSegurityTxt.TabIndex = 15
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(14, 227)
        Label8.Name = "Label8"
        Label8.Size = New Size(83, 15)
        Label8.TabIndex = 14
        Label8.Text = "Social segurity"
        ' 
        ' accionBtn
        ' 
        accionBtn.Location = New Point(204, 289)
        accionBtn.Name = "accionBtn"
        accionBtn.Size = New Size(138, 23)
        accionBtn.TabIndex = 16
        accionBtn.Text = "Register"
        accionBtn.UseVisualStyleBackColor = True
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.CustomFormat = "dd/MM/yyyy"
        DateTimePicker1.Format = DateTimePickerFormat.Short
        DateTimePicker1.Location = New Point(279, 82)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(200, 23)
        DateTimePicker1.TabIndex = 6
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(281, 65)
        Label4.Name = "Label4"
        Label4.Size = New Size(56, 15)
        Label4.TabIndex = 18
        Label4.Text = "BirthDate"
        ' 
        ' RegisterUpdateStudentForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(534, 324)
        Controls.Add(Label4)
        Controls.Add(DateTimePicker1)
        Controls.Add(accionBtn)
        Controls.Add(socialSegurityTxt)
        Controls.Add(Label8)
        Controls.Add(rfcTxt)
        Controls.Add(Label7)
        Controls.Add(phoneTxt)
        Controls.Add(Label6)
        Controls.Add(curpTxt)
        Controls.Add(Label5)
        Controls.Add(enrollmentTxt)
        Controls.Add(enrollmentLbl)
        Controls.Add(mothersTxt)
        Controls.Add(Label3)
        Controls.Add(lastNameTxt)
        Controls.Add(Label2)
        Controls.Add(nameTxt)
        Controls.Add(Label1)
        Name = "RegisterUpdateStudentForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "RegisterUpdateStudentForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents nameTxt As TextBox
    Friend WithEvents lastNameTxt As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents mothersTxt As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents enrollmentTxt As TextBox
    Friend WithEvents enrollmentLbl As Label
    Friend WithEvents curpTxt As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents phoneTxt As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents rfcTxt As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents socialSegurityTxt As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents accionBtn As Button
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label4 As Label
End Class
