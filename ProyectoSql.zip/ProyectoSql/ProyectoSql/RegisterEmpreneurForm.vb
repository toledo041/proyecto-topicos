﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class RegisterEmpreneurForm
    Public accion As String = "register"
    Public idEmpreneurObj As Integer = 0

    Private Sub RegisterEmpreneurForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadComboBoxStudent()
        loadComboBoxSEmployee()
    End Sub

    Private Sub ActionBtn_Click(sender As Object, e As EventArgs) Handles ActionBtn.Click

        Dim request As String = requestTxt.Text
        Dim objetive As String = objetiveTxt.Text
        Dim code As String = codeTxt.Text
        Dim workteam As String = workteamTxt.Text
        Dim startDate As Date = StartDatePicker.Value
        Dim endDate As Date = EndDatePicker.Value
        Dim duration As String = durationTxt.Text
        Dim idEmployee As Integer = 0
        Dim idStudent As Integer = 0

        If EmployeeComboBox.SelectedItem IsNot Nothing Then
            ' Obtener el objeto ComboBoxItem seleccionado
            Dim itemSeleccionado As ComboBoxEmployeeItem = DirectCast(EmployeeComboBox.SelectedItem, ComboBoxEmployeeItem)

            ' Obtener el ID del elemento seleccionado
            Dim idSeleccionado As Integer = itemSeleccionado.idEmployee
            idEmployee = idSeleccionado

        End If

        If StudentComboBox.SelectedItem IsNot Nothing Then
            ' Obtener el objeto ComboBoxItem seleccionado
            Dim itemSeleccionado As ComboBoxStudentItem = DirectCast(StudentComboBox.SelectedItem, ComboBoxStudentItem)

            ' Obtener el ID del elemento seleccionado
            Dim idSeleccionado As Integer = itemSeleccionado.idStudent
            idStudent = idSeleccionado

        End If

        If request = "" Or objetive = "" Or code = "" Or workteam = "" Or duration = "" Then
            MessageBox.Show("You must fill in all fields to continue", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            If accion = "register" Then

                Dim connectionString As String = ModuleGlobal.connectionString
                Dim consulta As String = "INSERT INTO Empreneur(request,objetive,codeOfEmpreneur,workteam,startdate,finaldate,duration,idEmployee,idStudent,status,idUserCreate,dateCreate)" &
                    " VALUES (@request,@objetive,@codeOfEmpreneur,@workteam,@startdate,@finaldate,@duration,@idEmployee, @idStudent, 1, @idUser, GETDATE())"


                ' Crear una conexión
                Using conexion As New SqlConnection(connectionString)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar parámetros con valores
                            comando.Parameters.AddWithValue("@request", request)
                            comando.Parameters.AddWithValue("@objetive", objetive)
                            comando.Parameters.AddWithValue("@codeOfEmpreneur", code)
                            comando.Parameters.AddWithValue("@workteam", workteam)
                            comando.Parameters.AddWithValue("@startdate", startDate)
                            comando.Parameters.AddWithValue("@finaldate", endDate)
                            comando.Parameters.AddWithValue("@duration", duration)
                            comando.Parameters.AddWithValue("@idEmployee", idEmployee)
                            comando.Parameters.AddWithValue("@idStudent", idStudent)
                            comando.Parameters.AddWithValue("@idUser", ModuleGlobal.idUser)


                            ' Ejecutar la consulta de inserción
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            Dim form1 As New EmpreneurForm()
                            form1.Show()
                            Me.Hide()
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            Else
                'Update

                Dim connectionString As String = ModuleGlobal.connectionString
                Dim consulta As String = "UPDATE Empreneur SET request = @request, objetive = @objetive, codeOfEmpreneur = @codeOfEmpreneur, workteam = @workteam," &
                "startdate = @startdate, finaldate = @finaldate, duration = @duration, idEmployee = @idEmployee, idStudent = @idStudent, idUserModified = @idUser, dateModified = GETDATE() " &
                " WHERE idEmpreneur = @id "


                ' Crear una conexión
                Using conexion As New SqlConnection(connectionString)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar parámetros con valores
                            comando.Parameters.AddWithValue("@request", request)
                            comando.Parameters.AddWithValue("@objetive", objetive)
                            comando.Parameters.AddWithValue("@codeOfEmpreneur", code)
                            comando.Parameters.AddWithValue("@workteam", workteam)
                            comando.Parameters.AddWithValue("@startdate", startDate)
                            comando.Parameters.AddWithValue("@finaldate", endDate)
                            comando.Parameters.AddWithValue("@duration", duration)
                            comando.Parameters.AddWithValue("@idEmployee", idEmployee)
                            comando.Parameters.AddWithValue("@idStudent", idStudent)
                            comando.Parameters.AddWithValue("@idUser", ModuleGlobal.idUser)
                            comando.Parameters.AddWithValue("@id", idEmpreneurObj)


                            ' Ejecutar la consulta de inserción
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            Dim form1 As New EmpreneurForm()
                            form1.Show()
                            Me.Hide()
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End If

        End If

    End Sub

    Private Sub loadComboBoxStudent()
        ' Ajusta la cadena de conexión según tu entorno
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL para obtener datos
        Dim consulta As String = "select idStudent, CONCAT(name,' ',lastName, ' ',mothersthestName) studentName from Student"

        Try
            ' Usar SqlConnection para conectarse a la base de datos
            Using conexion As New SqlConnection(cadenaConexion)
                ' Abrir la conexión
                conexion.Open()

                ' Usar SqlCommand para ejecutar la consulta
                Using comando As New SqlCommand(consulta, conexion)
                    ' Usar SqlDataReader para leer los resultados de la consulta
                    Using reader As SqlDataReader = comando.ExecuteReader()
                        ' Limpiar los elementos existentes en el ComboBox
                        StudentComboBox.Items.Clear()

                        ' Iterar a través de los resultados y agregar elementos al ComboBox
                        While reader.Read()
                            ' Agregar un elemento al ComboBox utilizando los datos de la consulta                            
                            StudentComboBox.Items.Add(New ComboBoxStudentItem() With {
                                .idStudent = reader.GetInt32(0),
                                .studentName = reader.GetString(1)
                            })
                        End While

                        ' Seleccionar el primer elemento si hay al menos uno
                        If StudentComboBox.Items.Count > 0 Then
                            StudentComboBox.SelectedIndex = 0
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar datos: " & ex.Message)
        End Try
    End Sub

    Private Sub loadComboBoxSEmployee()
        ' Ajusta la cadena de conexión según tu entorno
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL para obtener datos
        Dim consulta As String = "exec dbo.sp_getEmployees"

        Try
            ' Usar SqlConnection para conectarse a la base de datos
            Using conexion As New SqlConnection(cadenaConexion)
                ' Abrir la conexión
                conexion.Open()

                ' Usar SqlCommand para ejecutar la consulta
                Using comando As New SqlCommand(consulta, conexion)
                    ' Usar SqlDataReader para leer los resultados de la consulta
                    Using reader As SqlDataReader = comando.ExecuteReader()
                        ' Limpiar los elementos existentes en el ComboBox                        
                        EmployeeComboBox.Items.Clear()

                        ' Iterar a través de los resultados y agregar elementos al ComboBox
                        While reader.Read()
                            ' Agregar un elemento al ComboBox utilizando los datos de la consulta                            
                            EmployeeComboBox.Items.Add(New ComboBoxEmployeeItem() With {
                                .idEmployee = reader.GetInt32(0),
                                .employeeName = reader.GetString(1)
                            })
                        End While

                        ' Seleccionar el primer elemento si hay al menos uno
                        If EmployeeComboBox.Items.Count > 0 Then
                            EmployeeComboBox.SelectedIndex = 0
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar datos: " & ex.Message)
        End Try
    End Sub

    Public Class ComboBoxEmployeeItem
        Public Property idEmployee As Integer
        Public Property employeeName As String

        Public Overrides Function ToString() As String
            Return employeeName
        End Function
    End Class

    Public Class ComboBoxStudentItem
        Public Property idStudent As Integer
        Public Property studentName As String

        Public Overrides Function ToString() As String
            Return studentName
        End Function
    End Class

    Public Sub setParameters(idEmpreneur As String, request As String, objetive As String, code As String, workteam As String, startDate As String, endDate As String, duration As String, idEmployee As String, idStudent As String)
        idEmpreneurObj = idEmpreneur
        requestTxt.Text = request
        objetiveTxt.Text = objetive
        codeTxt.Text = code
        workteamTxt.Text = workteam
        StartDatePicker.Text = startDate
        EndDatePicker.Text = endDate
        durationTxt.Text = duration

        For Each item As ComboBoxEmployeeItem In EmployeeComboBox.Items
            If item.idEmployee = Convert.ToInt32(idEmployee) Then
                EmployeeComboBox.SelectedItem = item
                Exit For
            End If
        Next

        For Each item As ComboBoxStudentItem In StudentComboBox.Items
            If item.idStudent = Convert.ToInt32(idStudent) Then
                StudentComboBox.SelectedItem = item
                Exit For
            End If
        Next

        ActionBtn.Text = "Update"

    End Sub

    Private Sub RegisterEmpreneurForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim form1 As New EmpreneurForm()
        form1.Show()
        Me.Hide()
    End Sub
End Class