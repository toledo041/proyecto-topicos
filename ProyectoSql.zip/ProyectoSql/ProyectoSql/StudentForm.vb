﻿Imports System.Data.SqlClient

Public Class StudentForm
    Public idUser As Integer = 0
    Private Sub StudentForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CargarTabla()
        ' Crear una columna de botones
        Dim columnaBotones As New DataGridViewButtonColumn()
        columnaBotones.HeaderText = "Update"
        columnaBotones.Text = "Update"
        columnaBotones.UseColumnTextForButtonValue = True ' Esto permite mostrar el mismo texto en todos los botones

        ' Crear una columna de botones
        Dim columnaBotonesElim As New DataGridViewButtonColumn()
        columnaBotonesElim.HeaderText = "Delete"
        columnaBotonesElim.Text = "Delete"
        columnaBotonesElim.UseColumnTextForButtonValue = True ' Esto permite mostrar el mismo texto en todos los botones

        ' Agregar la columna al DataGridView
        DataGridView1.Columns.Add(columnaBotones)
        DataGridView1.Columns.Add(columnaBotonesElim)


    End Sub

    Private Sub CargarTabla()
        ' Cadena de conexión a SQL Server   User ID=tu_usuario;Password=tu_contraseña
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL
        Dim consulta As String = "select idStudent, name, lastName, mothersthestName, enrollment, curp, phone, rfc, socialSegurity from Student where status = 1 order by idStudent"

        ' Crear una conexión
        Using conexion As New SqlConnection(cadenaConexion)
            Try
                ' Abrir la conexión
                conexion.Open()

                ' Crear un adaptador de datos
                Using adaptador As New SqlDataAdapter(consulta, conexion)
                    ' Crear un DataSet para almacenar los resultados
                    Dim dataSet As New DataSet()

                    ' Llenar el DataSet con los resultados de la consulta
                    adaptador.Fill(dataSet, "Resultados")

                    ' Mostrar los resultados en el DataGridView
                    DataGridView1.DataSource = dataSet.Tables("Resultados")
                End Using
            Catch ex As Exception
                ' Manejar errores
                Console.WriteLine("Error: " & ex.Message)
            End Try
        End Using


    End Sub

    Private Sub RegisterStudentBtn_Click(sender As Object, e As EventArgs) Handles RegisterStudentBtn.Click
        ' Crear una instancia del Form2
        Dim form2 As New RegisterUpdateStudentForm()
        form2.accionObj = "register"
        form2.idUserObj = idUser
        ' Mostrar Form2
        form2.Show()

        ' Opcional: Ocultar Form1 si es necesario
        Me.Hide()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

        'MessageBox.Show("Botón Actualizar clickeado en la fila " & e.RowIndex.ToString() & " col " & e.ColumnIndex)
        ' Verificar si el clic fue en una celda de la columna de botones
        If e.ColumnIndex = 9 AndAlso e.RowIndex >= 0 Then
            ' Realizar acciones al hacer clic en el botón, por ejemplo, mostrar un mensaje
            'MessageBox.Show("Botón Actualizar clickeado en la fila " & e.RowIndex.ToString())
            Dim idStudent As String = DataGridView1.Rows(e.RowIndex).Cells("idStudent").Value.ToString()
            Dim name As String = DataGridView1.Rows(e.RowIndex).Cells("name").Value.ToString()
            Dim lastName As String = DataGridView1.Rows(e.RowIndex).Cells("lastName").Value.ToString()
            Dim mothersthestName As String = DataGridView1.Rows(e.RowIndex).Cells("mothersthestName").Value.ToString()
            Dim enrollment As String = DataGridView1.Rows(e.RowIndex).Cells("enrollment").Value.ToString()
            Dim curp As String = DataGridView1.Rows(e.RowIndex).Cells("curp").Value.ToString()
            Dim phone As String = DataGridView1.Rows(e.RowIndex).Cells("phone").Value.ToString()
            Dim rfc As String = DataGridView1.Rows(e.RowIndex).Cells("rfc").Value.ToString()
            Dim socialSegurity As String = DataGridView1.Rows(e.RowIndex).Cells("socialSegurity").Value.ToString()


            ' Crear una instancia del Form2
            Dim form2 As New RegisterUpdateStudentForm()
            form2.RecibirParametros(idStudent, name, lastName, mothersthestName, enrollment, curp, phone, rfc, socialSegurity, idUser, "update")

            ' Mostrar Form2
            form2.Show()

            ' Opcional: Ocultar Form1 si es necesario
            Me.Hide()


        End If

        If e.ColumnIndex = 10 AndAlso e.RowIndex >= 0 Then
            ' Realizar acciones al hacer clic en el botón, por ejemplo, mostrar un mensaje
            Dim idStudent As String = DataGridView1.Rows(e.RowIndex).Cells("idStudent").Value.ToString()

            ' Console.WriteLine(idStudent)

            Dim resultado As DialogResult = MessageBox.Show("¿You're sure to delete this record?", "Info", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Verificar la respuesta del usuario
            If resultado = DialogResult.Yes Then
                ' Realizar la acción si el usuario presionó "Sí"
                ' Cadena de conexión a SQL Server con autenticación de Windows
                Dim cadenaConexion As String = ModuleGlobal.connectionString

                ' ID del registro que deseas eliminar (puedes ajustar esto según tu lógica)
                'Dim idRegistroAEliminar As Integer = 123

                ' Consulta SQL de eliminación
                Dim consulta As String = "UPDATE Student SET status = 0 WHERE idStudent = @idRegistro"

                ' Crear una conexión
                Using conexion As New SqlConnection(cadenaConexion)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar el parámetro con el ID del registro a eliminar
                            comando.Parameters.AddWithValue("@idRegistro", idStudent)

                            ' Ejecutar la consulta de eliminación
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Successfully deleted record.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using

                CargarTabla()
            End If

        End If
    End Sub

    Private Sub StudentForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim form1 As New LoginForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub CompanyBtn_Click(sender As Object, e As EventArgs) Handles CompanyBtn.Click
        Dim form1 As New Form1()
        form1.idUser = idUser
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub companyStudentBtn_Click(sender As Object, e As EventArgs) Handles companyStudentBtn.Click

        Dim form1 As New CompanyStudentForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub empreneurBtn_Click(sender As Object, e As EventArgs) Handles empreneurBtn.Click
        Dim form1 As New EmpreneurForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub complementaryActivityBtn_Click(sender As Object, e As EventArgs) Handles complementaryActivityBtn.Click
        Dim form1 As New ComplementaryActivityForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim form1 As New ComplementaryActivityCompanyForm()
        form1.Show()
        Me.Hide()
    End Sub
End Class