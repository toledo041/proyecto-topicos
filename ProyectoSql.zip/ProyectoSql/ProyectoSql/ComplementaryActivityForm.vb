﻿Imports System.Data.SqlClient

Public Class ComplementaryActivityForm
    Private Sub ComplementaryActivityForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        CargarTabla()

        ' Crear una columna de botones
        Dim columnaBotones As New DataGridViewButtonColumn()
        columnaBotones.HeaderText = "Update"
        columnaBotones.Text = "Update"
        columnaBotones.UseColumnTextForButtonValue = True ' Esto permite mostrar el mismo texto en todos los botones

        ' Crear una columna de botones
        Dim columnaBotonesElim As New DataGridViewButtonColumn()
        columnaBotonesElim.HeaderText = "Delete"
        columnaBotonesElim.Text = "Delete"
        columnaBotonesElim.UseColumnTextForButtonValue = True ' Esto permite mostrar el mismo texto en todos los botones

        ' Agregar la columna al DataGridView
        DataGridView1.Columns.Add(columnaBotones)
        DataGridView1.Columns.Add(columnaBotonesElim)

    End Sub

    Private Sub ComplementaryActivityForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim form1 As New StudentForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim form1 As New RegisterComplementaryActivityForm()
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub CargarTabla()
        ' Cadena de conexión a SQL Server   User ID=tu_usuario;Password=tu_contraseña
        Dim cadenaConexion As String = ModuleGlobal.connectionString

        ' Consulta SQL
        Dim consulta As String = "exec dbo.sp_getComplementaryActivity"

        ' Crear una conexión
        Using conexion As New SqlConnection(cadenaConexion)
            Try
                ' Abrir la conexión
                conexion.Open()

                ' Crear un adaptador de datos
                Using adaptador As New SqlDataAdapter(consulta, conexion)
                    ' Crear un DataSet para almacenar los resultados
                    Dim dataSet As New DataSet()

                    ' Llenar el DataSet con los resultados de la consulta
                    adaptador.Fill(dataSet, "Resultados")

                    ' Mostrar los resultados en el DataGridView
                    DataGridView1.DataSource = dataSet.Tables("Resultados")
                End Using
            Catch ex As Exception
                ' Manejar errores
                Console.WriteLine("Error: " & ex.Message)
            End Try
        End Using


    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        'MessageBox.Show("Botón Actualizar clickeado en la fila " & e.RowIndex.ToString() & " col " & e.ColumnIndex)
        'Return
        ' Verificar si el clic fue en una celda de la columna de botones
        If e.ColumnIndex = 6 AndAlso e.RowIndex >= 0 Then
            ' Realizar acciones al hacer clic en el botón, por ejemplo, mostrar un mensaje
            'MessageBox.Show("Botón Actualizar clickeado en la fila " & e.RowIndex.ToString())
            Dim idComplementaryActivity As String = DataGridView1.Rows(e.RowIndex).Cells("idComplementaryActivity").Value.ToString()
            Dim activityName As String = DataGridView1.Rows(e.RowIndex).Cells("activityname").Value.ToString()
            Dim idActivity As String = DataGridView1.Rows(e.RowIndex).Cells("idStudent").Value.ToString()
            Dim idStudent As String = DataGridView1.Rows(e.RowIndex).Cells("idActivityType").Value.ToString()

            ' Crear una instancia del Form2
            Dim form2 As New RegisterComplementaryActivityForm()
            form2.setParameters(idComplementaryActivity, activityName, idActivity, idStudent)
            form2.action = "update"
            ' Mostrar Form2
            form2.Show()

            ' Opcional: Ocultar Form1 si es necesario
            Me.Hide()


        End If

        If e.ColumnIndex = 7 AndAlso e.RowIndex >= 0 Then
            ' Realizar acciones al hacer clic en el botón, por ejemplo, mostrar un mensaje
            Dim idComplementaryActivity As String = DataGridView1.Rows(e.RowIndex).Cells("idComplementaryActivity").Value.ToString()

            ' Console.WriteLine(idStudent)

            Dim resultado As DialogResult = MessageBox.Show("¿You're sure to delete this record?", "Info", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Verificar la respuesta del usuario
            If resultado = DialogResult.Yes Then
                ' Realizar la acción si el usuario presionó "Sí"
                ' Cadena de conexión a SQL Server con autenticación de Windows
                Dim cadenaConexion As String = ModuleGlobal.connectionString

                ' ID del registro que deseas eliminar (puedes ajustar esto según tu lógica)
                'Dim idRegistroAEliminar As Integer = 123

                ' Consulta SQL de eliminación
                Dim consulta As String = "UPDATE ComplementaryActivity SET status = 0 WHERE idComplementaryActivity = @idRegistro"

                ' Crear una conexión
                Using conexion As New SqlConnection(cadenaConexion)
                    Try
                        ' Abrir la conexión
                        conexion.Open()

                        ' Crear un comando con parámetros
                        Using comando As New SqlCommand(consulta, conexion)
                            ' Agregar el parámetro con el ID del registro a eliminar
                            comando.Parameters.AddWithValue("@idRegistro", idComplementaryActivity)

                            ' Ejecutar la consulta de eliminación
                            comando.ExecuteNonQuery()

                            ' Mensaje de éxito (puedes personalizarlo)
                            MessageBox.Show("Successfully deleted record.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End Using
                    Catch ex As Exception
                        ' Manejar errores
                        MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using

                CargarTabla()
            End If

        End If
    End Sub
End Class