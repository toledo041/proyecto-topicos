﻿Imports Microsoft.VisualBasic.ApplicationServices
Imports System.Data.SqlClient
Imports System.Runtime.CompilerServices

Public Class RegisterUpdateStudentForm

    Public Id As String, nameObj As String, lastNameObj As String, mothersObj As String, enrollmentObj As String, curpObj As String, phoneObj As String, rfcObj As String, socialSegurityObj As String
    Public accionObj As String
    Public idUserObj As Integer

    Private Sub RegisterUpdateStudentForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    ' Método para recibir el parámetro  idStudent, name, lastName, mothersthestName, enrollment, curp, phone, rfc, socialSegurity
    Public Sub RecibirParametros(IdStudent As String, name As String, lastName As String, mothersthestName As String, enrollment As String, curp As String, phone As String, rfc As String, socialSegurity As String, idUser As Integer, accion As String)
        ' Realizar acciones con el parámetro recibido
        Id = IdStudent
        nameObj = name
        lastNameObj = lastName
        mothersObj = mothersthestName
        enrollmentObj = enrollment
        curpObj = curp
        phoneObj = phone
        rfcObj = rfc
        socialSegurityObj = socialSegurity
        idUserObj = idUser
        accionObj = accion

        nameTxt.Text = name
        lastNameTxt.Text = lastName
        mothersTxt.Text = mothersthestName
        enrollmentTxt.Text = enrollment
        curpTxt.Text = curp
        phoneTxt.Text = phone
        rfcTxt.Text = rfc
        socialSegurityTxt.Text = socialSegurity

        accionBtn.Text = "Update"



    End Sub

    Private Sub RegisterUpdateStudentForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim form1 As New StudentForm()
        form1.idUser = idUserObj
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub accionBtn_Click(sender As Object, e As EventArgs) Handles accionBtn.Click

        Dim name As String = nameTxt.Text
        Dim lastName As String = lastNameTxt.Text
        Dim mothersthestName As String = mothersTxt.Text
        Dim enrollment As String = enrollmentTxt.Text
        Dim curp As String = curpTxt.Text
        Dim phone As String = phoneTxt.Text
        Dim rfc As String = rfcTxt.Text
        Dim socialSegurity As String = socialSegurityTxt.Text

        'MessageBox.Show("id element " & Id, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        'Return
        If name = "" Or lastName = "" Or mothersthestName = "" Or enrollment = "" Or curp = "" Or phone = "" Or rfc = "" Or socialSegurity = "" Then
            MessageBox.Show("You must fill in all fields to continue.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If


        If accionObj = "register" Then
            Dim connectionString As String = ModuleGlobal.connectionString
            Dim consulta As String = "INSERT INTO Student(name,lastName, mothersthestName, birthdate, enrollment, curp, phone, rfc, socialSegurity, idUserCreate, creationdate) VALUES (@name, @lastName, @mothersthestName, @birthdate, @enrollment, @curp, @phone, @rfc, @socialSegurity,@idUser,GETDATE())"


            ' Crear una conexión
            Using conexion As New SqlConnection(connectionString)
                Try
                    ' Abrir la conexión
                    conexion.Open()

                    ' Crear un comando con parámetros
                    Using comando As New SqlCommand(consulta, conexion)
                        ' Agregar parámetros con valores
                        comando.Parameters.AddWithValue("@name", name)
                        comando.Parameters.AddWithValue("@lastName", lastName)
                        comando.Parameters.AddWithValue("@mothersthestName", mothersthestName)
                        comando.Parameters.AddWithValue("@birthdate", DateTimePicker1.Value)
                        comando.Parameters.AddWithValue("@enrollment", enrollment)
                        comando.Parameters.AddWithValue("@curp", curp)
                        comando.Parameters.AddWithValue("@phone", phone)
                        comando.Parameters.AddWithValue("@rfc", rfc)
                        comando.Parameters.AddWithValue("@socialSegurity", socialSegurity)
                        comando.Parameters.AddWithValue("@idUser", ModuleGlobal.idUser)


                        ' Ejecutar la consulta de inserción
                        comando.ExecuteNonQuery()

                        ' Mensaje de éxito (puedes personalizarlo)
                        MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        Dim form1 As New StudentForm()
                        form1.idUser = idUserObj
                        form1.Show()
                        Me.Hide()
                    End Using
                Catch ex As Exception
                    ' Manejar errores
                    MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        Else
            'Update
            Dim connectionString As String = ModuleGlobal.connectionString
            Dim consulta As String = "UPDATE Student SET name = @name, lastName =  @lastName, mothersthestName = @mothersthestName, birthdate = @birthdate, enrollment = @enrollment, curp = @curp, phone = @phone, rfc = @rfc, socialSegurity = @socialSegurity, idUserModify = @idUser, modified = GETDATE() where idStudent = @id"
            '"VALUES (@name, @lastName, @mothersthestName, @birthdate, @enrollment, @curp, @phone, @rfc, @socialSegurity,@idUser,GETDATE())"


            ' Crear una conexión
            Using conexion As New SqlConnection(connectionString)
                Try
                    ' Abrir la conexión
                    conexion.Open()

                    ' Crear un comando con parámetros
                    Using comando As New SqlCommand(consulta, conexion)
                        ' Agregar parámetros con valores
                        comando.Parameters.AddWithValue("@name", name)
                        comando.Parameters.AddWithValue("@lastName", lastName)
                        comando.Parameters.AddWithValue("@mothersthestName", mothersthestName)
                        comando.Parameters.AddWithValue("@birthdate", DateTimePicker1.Value)
                        comando.Parameters.AddWithValue("@enrollment", enrollment)
                        comando.Parameters.AddWithValue("@curp", curp)
                        comando.Parameters.AddWithValue("@phone", phone)
                        comando.Parameters.AddWithValue("@rfc", rfc)
                        comando.Parameters.AddWithValue("@socialSegurity", socialSegurity)
                        comando.Parameters.AddWithValue("@idUser", ModuleGlobal.idUser)
                        comando.Parameters.AddWithValue("@id", Id)


                        ' Ejecutar la consulta de inserción
                        comando.ExecuteNonQuery()

                        ' Mensaje de éxito (puedes personalizarlo)
                        MessageBox.Show("Correctly inserted data..", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        Dim form1 As New StudentForm()
                        form1.idUser = idUserObj
                        form1.Show()
                        Me.Hide()
                    End Using
                Catch ex As Exception
                    ' Manejar errores
                    MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        End If

    End Sub
End Class